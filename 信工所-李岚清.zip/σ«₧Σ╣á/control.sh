#! /bin/bash

#脚本是作用是用来打开和关闭守护进程
WHOAMI=`whoami`

PID=`ps -u $WHOAMI | grep mytestdemo | awk '{print $2}'`

if (test "$1" = "start") then
	./server 8080
fi

if (test "$1" = "stop") then
	if (test "$PID" != "") then
		kill $PID
	fi
fi

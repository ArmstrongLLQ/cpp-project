//图片处理模块，待加入代码

#ifndef MODEL_H_
#define MODEL_H_

int load_model();

int input_image();

int output();

int do_model();

#endif

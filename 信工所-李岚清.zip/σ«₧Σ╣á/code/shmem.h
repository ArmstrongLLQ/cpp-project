//共享内存模块，读写共享内存

#ifndef _SHMDATA_H_HEADER
#define _SHMDATA_H_HEADER

#define TEXT_SZ 1024

struct shared_use_st
{
    char text[TEXT_SZ];//记录写入和读取的文本
};

//读共享内存
int shmread(void *shm, char *readbuf);

//写共享内存
int shmwrite(void *shm, char *writebuf);


#endif

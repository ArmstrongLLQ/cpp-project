#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include "sock.h"
#include "model.h"

int socket_create(int port)
{
    int st = socket(AF_INET, SOCK_STREAM, 0);//建立TCP socket
    if (0 == st)
    {
        return 0;//如果建立socket失败，返回0
    }
    int on = 0;
    if (setsockopt(st, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) == -1)//设置socket地址可重用
    {
        printf("setsockopt failed %s\n", strerror(errno));
        return 0;
    }
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(st, (struct sockaddr *) &addr, sizeof(addr)) == -1)//server端socket，所以需要绑定IP地址
    {
        printf("bind failed %s\n", strerror(errno));
        return 0;
    }
    if (listen(st, 20) == -1)
    {
        printf("listen failed %s\n", strerror(errno));
        return 0;
    }
    printf("listen %d success\n", port);
    return st;//server端socket建立成功,返回server端socket描述符
}

int socket_accept(int listen_st)//server端socket开始accept的函数
{
    struct sockaddr_in client_addr;

    unsigned int len = 1;

    len = sizeof(client_addr);
    memset(&client_addr, 0, sizeof(client_addr));
    int client_st = accept(listen_st, (struct sockaddr *) &client_addr,
                           &len);//accept阻塞，直到有client连接到server才返回
    if (client_st == -1)
    {
        printf("accept failed %s\n", strerror(errno));
        return 0;
    } else
    {
        printf("accept by %s\n", inet_ntoa(client_addr.sin_addr));
        return client_st;//有client连接到server，返回client的socket描述符
    }
}


int connect_work(int port, int *st, int *listen_st)//server端socket在port指定的端口上listen
{
    *listen_st = socket_create(port);//建立server端socket，在port指定端口listen
    if (*listen_st == 0)//如果创建服务端socket失败，函数返回0
        return 0;
    *st = socket_accept(*listen_st);//如果有client连接到达，socket_accept函数返回client的socket描述符
    if (*st == 0)
        return 0;
    return 1;
}

//获取url，后面改为json处理程序
int geturl(int st, char *url_buf)
{
    memset(url_buf, 0, 1024);
    int rv = recv(st, url_buf, 1024, 0);
   
    return rv;
}

//关闭套接字
int close_connect(int *st, int *listen_st)
{
    close(*st);
    close(*listen_st);
    return 0;
}

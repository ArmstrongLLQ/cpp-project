//信号量模块，用来控制共享内存进程间通信的同步

#ifndef sem_h
#define sem_h

#include <stdio.h>

/*union semun
{
	int val;
	struct semid_ds *buf;
	unsigned short *arry;
};
*/
//创建信号量
int sem_create(int key);

//设置信号量
int set_semvalue(int sem_id);

//删除信号量
void del_semvalue(int sem_id);

//V操作
int semaphore_v(int sem_id);

//P操作
int semaphore_p(int sem_id);

#endif /* sem_h */

//套接字模块，使用TCP/IP通信

#ifndef SOCK_H_
#define SOCK_H_

//建立TCP/IP连接
int connect_work(int port, int *st, int *listen_st);

//接收客户端消息
int geturl(int st, char *url_buf);

//关闭套接字
int close_connect(int *st, int *listen_st);

#endif /* SOCK_H_ */


#include <stdio.h>
#include "model.h"

int load_model()
{
	printf("loading model...\n");
	return 0;
}

int input_image()
{
	printf("input image...\n");
	return 0;
}

int output()
{
	
	printf("output...\n");
	return 0;
}

int do_model(const char *url)
{
	load_model();
	input_image();
	output();
	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include "model.h"
#include "sock.h"
#include "shmem.h"
#include "sem.h"
#include <sys/sem.h>

int mydaemon();//将进程变为守护进程

int main(int arg, char* args[])
{
    
    if(arg < 2)
    {
        return -1;
    }
     
    /*
    //守护进程，实际运行的时候再取消注释
    
    int ret = mydaemon();//将进程变为守护进程
    if(ret != 0)
    {
        return -1;
    }
    */
    
    //创建一个共享内存,用来让父进程与子进程进行通信
    int shmid;
    shmid = shmget((key_t)1235, 1024*10, 0666|IPC_CREAT);
    if(shmid == -1)
    {
        printf( "shmget failed\n");
        exit(EXIT_FAILURE);
    }
    
    
    //fork子进程,子进程用来处理图片,父进程用来通信
    pid_t pt;
    pt = fork();
    if(pt == -1)
    {
        printf( "fork child fail\n");
        return -1;
    }

    if(pt > 0)//父进程，用来通信
    {

        int iport = atoi(args[1]);//将第一个参数转化为端口号，server端socket要在这个端口号上listen
        if (iport == 0)
        {
            printf( "port %d is invalid\n", iport);
            return -1;
        }
        

        //创建一个共享内存,用来让父进程与子进程进行通信
        int shmid;
        shmid = shmget((key_t)1235, 1024, 0666|IPC_CREAT);
        if(shmid == -1)
        {
            printf( "shmget failed\n");
            exit(EXIT_FAILURE);
        }
        
        //创建socket通信
        int st, listen_st;
        connect_work(iport, &st, &listen_st);
        char writebuf[1024];
        
        void *shm = NULL;
        
        //将共享内存连接 到当前进程的地址空间
        shm = shmat(shmid, (void*)0, 0);
        if(shm == (void*)-1)
        {
            printf( "shmat failed\n");
            return -1;
        }
        
        //创建信号量
        int semid = sem_create(1234);
        if (semid == -1)
        {
            return -1;
        }
        
        if (set_semvalue(semid) == 0)
        {
            printf( "set_semvalue failed\n");
            return -1;
        }
        
        while(1)
        {
            int recv_status = geturl(st, writebuf);
            if (recv_status == -1)
            {
                printf( "recv error %s\n", strerror(errno));
            }else if (recv_status == 0)
            {
                printf( "disconnected\n");
                break;
            }
            if (semaphore_p(semid) != 1)
            {
                return -1;
            }
            int ret = shmwrite(shm, writebuf);
            if(ret == 1)
            {
                semaphore_v(semid);
                break;
            }
            
            semaphore_v(semid);
        }
        
        //删除信号量
        del_semvalue(semid);
        
        //把共享内存从当前进程中分离
        if(shmdt(shm) == -1)
        {
            printf( "shmdt failed\n");
            return -1;
        }
        //删除共享内存
        if(shmctl(shmid, IPC_RMID, 0) == -1)
        {
            printf( "shmctl(IPC_RMID) failed\n");
            return -1;
        }
        //关闭套接字
        close_connect(&st, &listen_st);
        return 0;
    }

    
    if(pt == 0)
    {
        //创建一个共享内存,用来让父进程与子进程进行通信
        int shmid;
        shmid = shmget((key_t)1235, 1024, 0666|IPC_CREAT);
        if(shmid == -1)
        {
            printf( "shmget failed\n");
            exit(EXIT_FAILURE);
        }
        
        //将共享内存连接 到当前进程的地址空间
        void *shm = shmat(shmid, (void*)0, 0);
        if(shm == (void*)-1)
        {
            printf( "shmat failed\n");
            return -1;
        }
        
        //创建信号量
        int semid = sem_create(1234);
        if (semid == -1)
        {
            return -1;
        }
        
        //设置信号量
        if (set_semvalue(semid) == 0)
        {
            printf( "set_semvalue failed\n");
            return -1;
        }

        
        char readbuf[1024];
        memset(readbuf, 0, sizeof(readbuf));
        while (1)
        {
            if (semaphore_p(semid) != 1)//P操作
            {
                return -1;
            }
            int ret = shmread(shm, readbuf);//读共享内存
            if(ret == 1)
            {
                semaphore_v(semid);//V操作
                break;
            }
            
            semaphore_v(semid);
        }
        
        /*
        //删除信号量
        del_semvalue(semid);
        
        //把共享内存从当前进程中分离
        if(shmdt(shm) == -1)
        {
            printf( "shmdt failed\n");
            return -1;
        }
        //删除共享内存
        if(shmctl(shmid, IPC_RMID, 0) == -1)
        {
            printf( "shmctl(IPC_RMID) failed\n");
            return -1;
        }
         //父进程结束时已经删除，这里不用再删一次了。
         */
        return 0;
        
    }

    return 0;
}


int mydaemon()
{
    pid_t daemon;
    daemon = fork();
    if (daemon == -1)
    {
        return -1;
    }
    if (daemon > 0)//父进程退出
    {
        exit(0);
    }
    if (daemon == 0)//子进程脱离控制台
    {
        setsid();
        chdir("/");
        umask(0);

        close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);

        int stdfd = open ("/dev/null", O_RDWR);
        dup2(stdfd, STDOUT_FILENO);
        dup2(stdfd, STDERR_FILENO);

    }
    return 0;
}

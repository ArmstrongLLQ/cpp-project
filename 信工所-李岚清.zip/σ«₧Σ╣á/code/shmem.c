#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/shm.h>
#include "shmem.h"
#include "sem.h"

int shmwrite(void *shm, char *writebuf)
{
    struct shared_use_st *shared = NULL;
    
    //设置共享内存
    shared = (struct shared_use_st*)shm;
    
    strncpy(shared->text, writebuf, TEXT_SZ);
    //输入了end，退出循环（程序）
    if(strncmp(writebuf, "end", 3) == 0)
        return 1;
    
    
    return 0;
}

int shmread(void *shm, char *readbuf)
{
    struct shared_use_st *shared;//指向shm
    
    //设置共享内存
    shared = (struct shared_use_st*)shm;
    strncpy(readbuf, shared->text, 1024);
    printf("%s\n", readbuf);
    sleep(1);
    //输入了end，退出循环（程序）
    if(strncmp(shared->text, "end", 3) == 0)
        return 1;
    
    return 0;
}
